# MixerX EIP-7702 Authorization Utility

Static offline utility for generating a single EIP-7702 authorization hex string.

## Files

- `index.html` - the page to open in a browser
- `style.css` - MixerX-like static styling
- `app.js` - authorization generation logic and network constants
- `ethers.umd.min.js` - local `ethers` v6 browser bundle

All files are intentionally kept at the repository root so a release archive is easy to inspect.

## Usage

1. Download the release archive and verify its published SHA-256 hash.
2. Disconnect from the internet.
3. Open `index.html` locally.
4. Enter the private key.
5. Check the selected network and Paymaster address.
6. Generate and copy the authorization hex string.

The page does not make network requests. The private key is only used locally in the browser to sign the authorization.

## Release Verification

We recommend downloading the official release archive instead of using a repository checkout directly. Before opening `index.html`, compare the SHA-256 hash of the downloaded archive with the hash published in the release description.

## What This Authorization Does

This is a high-risk operation.

The authorization does not send funds by itself. It creates a signed permission that can be placed into a future transaction. When that transaction is sent, your wallet address can run code from the Paymaster address selected in this page.

In simpler terms: you are allowing a smart contract to act as the code for your wallet address on one specific network and nonce.

If the Paymaster address is wrong or malicious, your wallet can be compromised almost like your private key was leaked. Always verify that the Paymaster address is the official MixerX Paymaster for the selected network before copying the generated authorization.

Changing your account nonce, for example by sending a 0 ETH transaction to yourself, invalidates only an unused authorization signed for the old nonce. If the authorization has already been submitted and delegation is active, reset it by signing a new EIP-7702 authorization to the zero address using the current nonce.

## Verifying ethers.umd.min.js

This release includes `ethers.umd.min.js` from the official npm package `ethers@6.16.0`.

Expected SHA-256:

```text
9a85a5aa81305f85e6546452fd2093a8a68932bed3cec4f6491e4d031a90bc95  ethers.umd.min.js
```

Verify against the official npm package:

```bash
npm view ethers@6.16.0 dist.integrity dist.tarball
npm pack ethers@6.16.0
tar -xOf ethers-6.16.0.tgz package/dist/ethers.umd.min.js | shasum -a 256
shasum -a 256 ethers.umd.min.js
```

Both `shasum` outputs must match.

## Networks

| Network | Chain ID | Paymaster address |
| --- | ---: | --- |
| Mainnet | 1 | `0x0000000000000000000000000000000000000000` |
| Sepolia Testnet | 11155111 | `0xcbE122De149E6B5bCF4fcbD3677E6FD1DfE5A511` |

## Output Format

The output is an RLP hex string containing:

```text
[chainId, paymasterAddress, nonce, yParity, r, s]
```

The paymaster service can decode it and pass the decoded fields as one item in `authorizationList`.
