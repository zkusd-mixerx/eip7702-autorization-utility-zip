(function () {
  "use strict";

  var ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";

  var NETWORKS = {
    mainnet: {
      label: "Mainnet",
      chainId: 1n,
      paymasterAddress: ZERO_ADDRESS
    },
    sepolia: {
      label: "Sepolia Testnet",
      chainId: 11155111n,
      paymasterAddress: "0xb433968BaC696d2134074369b39d83F68bA6E489"
    }
  };

  var form = document.getElementById("authorization-form");
  var privateKeyInput = document.getElementById("private-key");
  var togglePrivateKeyButton = document.getElementById("toggle-private-key");
  var networkDropdown = document.getElementById("network-dropdown");
  var networkTrigger = document.getElementById("network-trigger");
  var networkLabel = document.getElementById("network-label");
  var networkMenu = document.getElementById("network-menu");
  var networkItems = Array.prototype.slice.call(document.querySelectorAll(".dropdown__item"));
  var nonceInput = document.getElementById("nonce");
  var paymasterAddressNode = document.getElementById("paymaster-address");
  var chainIdNode = document.getElementById("chain-id");
  var errorNode = document.getElementById("error");
  var resultNode = document.getElementById("result");
  var outputNode = document.getElementById("authorization-output");
  var accountAddressNode = document.getElementById("account-address");
  var copyButton = document.getElementById("copy");
  var clearButton = document.getElementById("clear");

  function selectedNetwork() {
    return NETWORKS[networkDropdown.dataset.value] || NETWORKS.mainnet;
  }

  function normalizePrivateKey(value) {
    var trimmed = value.trim();
    if (/^[0-9a-fA-F]{64}$/.test(trimmed)) {
      return "0x" + trimmed;
    }
    return trimmed;
  }

  function parsePrivateKey(value) {
    var privateKey = normalizePrivateKey(value);
    if (!/^0x[0-9a-fA-F]{64}$/.test(privateKey)) {
      throw new Error("Private key must be 32 bytes hex, with or without 0x prefix.");
    }
    return privateKey;
  }

  function parseNonce(value) {
    var normalized = value.trim();
    if (!/^\d+$/.test(normalized)) {
      throw new Error("Nonce must be a non-negative integer.");
    }
    return BigInt(normalized);
  }

  function toRlpScalar(value) {
    var ethersLib = window.ethers;
    var hex = ethersLib.toBeHex(value);
    return hex === "0x" ? "0x00" : hex;
  }

  function formatAuthorizationHex(auth) {
    var ethersLib = window.ethers;
    return ethersLib.encodeRlp([
      toRlpScalar(auth.chainId),
      auth.address,
      toRlpScalar(auth.nonce),
      toRlpScalar(BigInt(auth.signature.yParity)),
      auth.signature.r,
      auth.signature.s
    ]);
  }

  function setError(message) {
    errorNode.textContent = message;
    errorNode.hidden = false;
  }

  function clearError() {
    errorNode.textContent = "";
    errorNode.hidden = true;
  }

  function updateNetworkSummary() {
    var network = selectedNetwork();
    paymasterAddressNode.textContent = network.paymasterAddress;
    chainIdNode.textContent = network.chainId.toString();
  }

  function clearResult() {
    resultNode.hidden = true;
    outputNode.value = "";
    accountAddressNode.textContent = "";
  }

  function closeNetworkMenu() {
    networkDropdown.classList.remove("is-open");
    networkMenu.hidden = true;
    networkTrigger.setAttribute("aria-expanded", "false");
  }

  function openNetworkMenu() {
    networkDropdown.classList.add("is-open");
    networkMenu.hidden = false;
    networkTrigger.setAttribute("aria-expanded", "true");
  }

  function toggleNetworkMenu() {
    if (networkMenu.hidden) {
      openNetworkMenu();
    } else {
      closeNetworkMenu();
    }
  }

  function selectNetwork(value) {
    var network = NETWORKS[value] || NETWORKS.mainnet;
    networkDropdown.dataset.value = value;
    networkLabel.textContent = network.label;
    networkItems.forEach(function (item) {
      var isSelected = item.dataset.value === value;
      item.classList.toggle("is-selected", isSelected);
      item.setAttribute("aria-selected", isSelected ? "true" : "false");
    });
    updateNetworkSummary();
    clearResult();
    closeNetworkMenu();
  }

  function generateAuthorization(event) {
    event.preventDefault();
    clearError();
    clearResult();

    try {
      if (!window.ethers) {
        throw new Error("Local ethers bundle is not loaded.");
      }

      var ethersLib = window.ethers;
      var network = selectedNetwork();
      var privateKey = parsePrivateKey(privateKeyInput.value);
      var nonce = parseNonce(nonceInput.value);
      var wallet = new ethersLib.Wallet(privateKey);
      var authorization = wallet.authorizeSync({
        address: network.paymasterAddress,
        chainId: network.chainId,
        nonce: nonce
      });
      var recovered = ethersLib.verifyAuthorization(
        {
          address: authorization.address,
          chainId: authorization.chainId,
          nonce: authorization.nonce
        },
        authorization.signature
      );

      if (recovered.toLowerCase() !== wallet.address.toLowerCase()) {
        throw new Error("Generated authorization failed signature verification.");
      }

      outputNode.value = formatAuthorizationHex(authorization);
      accountAddressNode.textContent = wallet.address;
      resultNode.hidden = false;
      outputNode.focus();
      outputNode.select();
    } catch (error) {
      setError(error && error.message ? error.message : "Failed to generate authorization.");
    }
  }

  async function copyOutput() {
    clearError();
    if (!outputNode.value) {
      return;
    }

    try {
      await navigator.clipboard.writeText(outputNode.value);
      copyButton.textContent = "Copied";
      setTimeout(function () {
        copyButton.textContent = "Copy";
      }, 1200);
    } catch (_error) {
      outputNode.focus();
      outputNode.select();
      setError("Copy failed. Select the authorization hex manually.");
    }
  }

  function clearAll() {
    privateKeyInput.value = "";
    nonceInput.value = "0";
    selectNetwork("mainnet");
    clearError();
    clearResult();
    privateKeyInput.focus();
  }

  togglePrivateKeyButton.addEventListener("click", function () {
    var isHidden = privateKeyInput.classList.toggle("input--secret");
    togglePrivateKeyButton.textContent = isHidden ? "Show" : "Hide";
  });

  networkTrigger.addEventListener("click", toggleNetworkMenu);
  networkTrigger.addEventListener("keydown", function (event) {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      toggleNetworkMenu();
    }
    if (event.key === "Escape") {
      closeNetworkMenu();
    }
  });

  networkItems.forEach(function (item) {
    item.addEventListener("click", function () {
      selectNetwork(item.dataset.value);
    });
    item.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        closeNetworkMenu();
        networkTrigger.focus();
      }
    });
  });

  document.addEventListener("mousedown", function (event) {
    if (!networkDropdown.contains(event.target)) {
      closeNetworkMenu();
    }
  });

  form.addEventListener("submit", generateAuthorization);
  copyButton.addEventListener("click", copyOutput);
  clearButton.addEventListener("click", clearAll);
  updateNetworkSummary();
})();
